#!/bin/bash

run()
{
	sudo ./run1.sh
	sudo ./run2.sh
	sudo ./run3.sh

}


run
